/**
 * ClinicPro — Firebase Shared Core
 * ملف مشترك للتحقق من الهوية والوصول لبيانات العيادة
 */

// ======= FIREBASE CONFIG =======
// يمكن تمرير هذه القيم من متغيرات البيئة عبر window.__ENV__
window.FIREBASE_CONFIG = {
  apiKey: window.__FIREBASE_API_KEY__ || "AIzaSyDEMO_REPLACE_WITH_REAL_KEY",
  authDomain: window.__FIREBASE_AUTH_DOMAIN__ || "clinicpro-demo.firebaseapp.com",
  projectId: window.__FIREBASE_PROJECT_ID__ || "clinicpro-demo",
  storageBucket: window.__FIREBASE_STORAGE_BUCKET__ || "clinicpro-demo.appspot.com",
  messagingSenderId: window.__FIREBASE_MESSAGING_SENDER_ID__ || "000000000000",
  appId: window.__FIREBASE_APP_ID__ || "1:000000000000:web:0000000000000000"
};

// ======= FIREBASE INIT =======
window.initFirebaseCore = function() {
  try {
    if (!firebase.apps || !firebase.apps.length) {
      firebase.initializeApp(window.FIREBASE_CONFIG);
    }
    window.fbdb = firebase.firestore();
    return true;
  } catch(e) {
    console.warn('Firebase unavailable, using localStorage fallback:', e.message);
    window.fbdb = null;
    return false;
  }
};

// ======= CLINIC AUTH =======
window.getClinicIdFromUrl = function() {
  return new URLSearchParams(window.location.search).get('clinic');
};

/**
 * Fetch clinic data from Firestore or localStorage fallback
 */
window.fetchClinicData = async function(clinicId) {
  if (!clinicId) return null;
  
  if (window.fbdb) {
    try {
      const doc = await window.fbdb.collection('clinics').doc(clinicId).get();
      if (doc.exists) return { id: doc.id, ...doc.data() };
    } catch(e) {
      console.warn('Firestore fetch failed:', e);
    }
  }
  
  // localStorage fallback
  const all = JSON.parse(localStorage.getItem('clinicpro_dist_clinics') || '[]');
  return all.find(c => c.id === clinicId) || null;
};

/**
 * Real-time listener for clinic data changes
 */
window.listenClinicData = function(clinicId, callback) {
  if (!clinicId) return () => {};
  
  if (window.fbdb) {
    return window.fbdb.collection('clinics').doc(clinicId).onSnapshot(doc => {
      if (doc.exists) callback({ id: doc.id, ...doc.data() });
    });
  }
  
  // localStorage polling fallback (every 2s)
  const interval = setInterval(() => {
    const all = JSON.parse(localStorage.getItem('clinicpro_dist_clinics') || '[]');
    const c = all.find(x => x.id === clinicId);
    if (c) callback(c);
  }, 2000);
  
  return () => clearInterval(interval);
};

/**
 * Listen to clinic's live data (appointments, patients, etc.)
 */
window.listenCollection = function(clinicId, collName, callback) {
  if (!clinicId || !collName) return () => {};
  
  const key = `cp_${clinicId}_${collName}`;
  
  if (window.fbdb) {
    return window.fbdb
      .collection('clinics').doc(clinicId)
      .collection(collName)
      .orderBy('createdAt', 'desc')
      .onSnapshot(snap => {
        const items = [];
        snap.forEach(d => items.push({ id: d.id, ...d.data() }));
        callback(items);
        localStorage.setItem(key, JSON.stringify(items)); // cache locally
      });
  }
  
  // localStorage fallback
  const poll = () => {
    const data = JSON.parse(localStorage.getItem(key) || '[]');
    callback(data);
  };
  poll();
  const interval = setInterval(poll, 1500);
  return () => clearInterval(interval);
};

/**
 * Save a document to clinic subcollection
 */
window.saveDoc = async function(clinicId, collName, docId, data) {
  const key = `cp_${clinicId}_${collName}`;
  
  if (window.fbdb) {
    try {
      const ref = window.fbdb.collection('clinics').doc(clinicId).collection(collName).doc(docId);
      await ref.set({ ...data, updatedAt: new Date().toISOString() }, { merge: true });
      return true;
    } catch(e) {
      console.warn('Firestore save failed:', e);
    }
  }
  
  // localStorage fallback
  const existing = JSON.parse(localStorage.getItem(key) || '[]');
  const idx = existing.findIndex(x => x.id === docId);
  const newDoc = { ...data, id: docId, updatedAt: new Date().toISOString() };
  if (idx >= 0) existing[idx] = newDoc; else existing.unshift(newDoc);
  localStorage.setItem(key, JSON.stringify(existing));
  
  // Broadcast change
  try { localStorage.setItem(`cp_${clinicId}_pulse`, JSON.stringify({ t: Date.now(), col: collName, id: docId })); } catch(e) {}
  return true;
};

/**
 * Update a field in clinic main document
 */
window.updateClinicDoc = async function(clinicId, data) {
  if (window.fbdb) {
    try {
      await window.fbdb.collection('clinics').doc(clinicId).update({ ...data, updatedAt: new Date().toISOString() });
      return true;
    } catch(e) {}
  }
  
  const all = JSON.parse(localStorage.getItem('clinicpro_dist_clinics') || '[]');
  const idx = all.findIndex(c => c.id === clinicId);
  if (idx >= 0) {
    all[idx] = { ...all[idx], ...data, updatedAt: new Date().toISOString() };
    localStorage.setItem('clinicpro_dist_clinics', JSON.stringify(all));
  }
  return true;
};

/**
 * Delete a document
 */
window.deleteDoc = async function(clinicId, collName, docId) {
  const key = `cp_${clinicId}_${collName}`;
  
  if (window.fbdb) {
    try {
      await window.fbdb.collection('clinics').doc(clinicId).collection(collName).doc(docId).delete();
      return true;
    } catch(e) {}
  }
  
  const existing = JSON.parse(localStorage.getItem(key) || '[]');
  localStorage.setItem(key, JSON.stringify(existing.filter(x => x.id !== docId)));
  return true;
};

// ======= ROLE AUTHENTICATION =======
window.authenticateRole = async function(clinicId, requiredRole) {
  const clinic = await window.fetchClinicData(clinicId);
  if (!clinic) return { success: false, error: 'لم يتم العثور على العيادة. تحقق من الرابط.' };
  if (clinic.status === 'suspended') return { success: false, error: 'تم إيقاف هذه النسخة. تواصل مع الموزع.' };
  
  const sessionKey = `cp_session_${clinicId}`;
  const session = JSON.parse(sessionStorage.getItem(sessionKey) || 'null');
  if (session && session.role === requiredRole) {
    const userData = clinic.users?.[requiredRole];
    return { success: true, clinic, user: { ...userData, role: requiredRole }, session };
  }
  
  return { success: false, clinic, requiresLogin: true };
};

window.loginToClinic = function(clinic, role, email, password) {
  const userData = clinic.users?.[role];
  if (!userData) return { success: false, error: 'هذا الدور غير متاح في هذه العيادة.' };
  
  if (userData.email !== email || userData.password !== password) {
    return { success: false, error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' };
  }
  
  const session = { role, email, name: userData.name, clinicId: clinic.id, loginAt: new Date().toISOString() };
  sessionStorage.setItem(`cp_session_${clinic.id}`, JSON.stringify(session));
  return { success: true, user: { ...userData, role }, session };
};

window.logoutFromClinic = function(clinicId) {
  sessionStorage.removeItem(`cp_session_${clinicId}`);
};

// ======= UTILS =======
window.uid = () => '_' + Math.random().toString(36).slice(2, 11);
window.todayISO = () => new Date().toISOString().slice(0, 10);
window.nowTime = () => new Date().toTimeString().slice(0, 5);
window.pad = (n, l) => String(n).padStart(l, '0');
window.fmtDate = d => {
  if (!d) return '—';
  try { return new Date(d + 'T00:00:00').toLocaleDateString('ar-EG', { day: '2-digit', month: '2-digit', year: 'numeric' }); }
  catch(e) { return d; }
};
window.calcAge = dob => {
  if (!dob) return '—';
  try {
    const b = new Date(dob), t = new Date();
    let a = t.getFullYear() - b.getFullYear();
    if (t.getMonth() - b.getMonth() < 0 || (t.getMonth() - b.getMonth() === 0 && t.getDate() < b.getDate())) a--;
    return a >= 0 ? a : '—';
  } catch(e) { return '—'; }
};

window.ROLE_LABELS = { admin: 'مدير العيادة', doctor: 'الطبيب المعالج', reception: 'موظفة الاستقبال' };
